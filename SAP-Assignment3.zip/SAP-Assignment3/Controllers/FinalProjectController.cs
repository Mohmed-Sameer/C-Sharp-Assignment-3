﻿using Microsoft.AspNetCore.Mvc;

namespace SAP_Assignment3.Controllers
{
    public class FinalProjectController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }
    }
}

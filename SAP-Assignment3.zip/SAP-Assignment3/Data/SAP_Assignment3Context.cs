﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SAP_Assignment3.Models;

namespace SAP_Assignment3.Data
{
    public class SAP_Assignment3Context : DbContext
    {
        public SAP_Assignment3Context (DbContextOptions<SAP_Assignment3Context> options)
            : base(options)
        {
        }

        public DbSet<SAP_Assignment3.Models.Employee> Employee { get; set; } = default!;
    }
}
